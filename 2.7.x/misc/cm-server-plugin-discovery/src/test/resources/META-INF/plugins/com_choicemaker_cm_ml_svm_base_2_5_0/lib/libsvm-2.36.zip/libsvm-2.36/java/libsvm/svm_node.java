package libsvm;
public class svm_node
{
	public int index;
	public double value;
}
