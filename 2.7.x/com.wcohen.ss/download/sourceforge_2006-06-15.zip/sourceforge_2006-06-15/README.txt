Source code and supporting stuff for the "secondstring" project.  This
is a bunch of fancy soft string matching routines, with some
accompanying datasets.

To run/build this you need ant (http://ant.apache.org/, a java-based
make tool) and junit.jar (http://www.junit.org/, a framework for
testing).  Junit.jar needs to be on your classpath.
