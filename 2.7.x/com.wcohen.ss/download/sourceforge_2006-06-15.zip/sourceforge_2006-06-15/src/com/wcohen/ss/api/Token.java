package com.wcohen.ss.api;


/**
 * An interned version of a string.    
 *
 */

public interface Token
{
	public String getValue();
	public int getIndex();
}
