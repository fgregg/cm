export CLASSPATH=.:./class:./jars/cls.jar:./jars/jwf.jar:./jars/klingerIncludes.jar


